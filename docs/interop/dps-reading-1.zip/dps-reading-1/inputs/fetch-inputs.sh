#!/bin/sh
# DPS reading 1 - action binding and the person approval, from the text
# Downloads exactly the allowed inputs at pinned commits and checks their SHA-256.
# Usage: sh dps-reading-1-fetch-inputs.sh [output-dir]   (default: inputs)
set -eu
OUT=${1:-inputs}
DPS=https://raw.githubusercontent.com/decision-provenance-standard/standard/c9043722384f784ae578ae0a64400be8a3864259
LL=https://raw.githubusercontent.com/Laurent-Lemonnier/dps-scitt-decision-layer/fdc5f6352795fc713309cd25ac2669d22840e0cc
if command -v sha256sum >/dev/null 2>&1; then CHECK="sha256sum -c --quiet -"; else CHECK="shasum -a 256 -c --quiet -"; fi
fetch() { base=$1; dir=$2; sums=$3
  printf '%s\n' "$sums" | while read -r h p; do
    mkdir -p "$OUT/$dir/$(dirname "$p")"
    curl -fsSL "$base/$p" -o "$OUT/$dir/$p"
  done
  (cd "$OUT/$dir" && printf '%s\n' "$sums" | $CHECK) || { echo "SHA-256 MISMATCH in $dir: stop, do not proceed" >&2; exit 1; }
  printf '%s\n' "$sums" > "$OUT/$dir/SHA256SUMS"
  echo "ok: $dir, $(printf '%s\n' "$sums" | wc -l | tr -d ' ') files verified"
}
fetch "$DPS" standard "$(cat <<'SUMS'
38b397e9b34044ceb6ab57eaeec6a888c190d2027dc9f7b2b7d6b863f400ef66  extensions/README.md
baf8e56ec099cb800a6e3d5681204dbac0c3b7e5fe7ede84e8fc3dc935db5ac9  extensions/action-binding/README.md
578d46a2dc6c2b65ef2b375228d886ee2846bb3e8613fef90cc4cef4505c2c23  extensions/action-binding/schemas/execution-evidence.schema.json
d47e92686e19c30d5f1c0457b20ef84a82b3cd43aa89934b89c44b20e8aea106  extensions/action-binding/schemas/verification-report.schema.json
94b8ceb3920fe3c4e1ae0cccfbde1cf8a3baf615c182fbf99225dff8174f0274  extensions/action-binding/tests/cases.json
cb7876b2a3056c23063da9ffee3650d28fc05613e24a02a8eaa28aa171f6aa6d  extensions/action-binding/tests/vectors.json
20b3f8f5b8dd327708ce65e9f52144750c890429aeb61e2efbbf623f49fa71a9  extensions/portable-verification/README.md
7e7d67620e95b8cd948c1dcf05361076418ea6009d92b5662cf35203d1c5dc8a  extensions/portable-verification/schemas/verification-export.schema.json
1c77f305d68923eef7d8bc7846597785a4256fad323c6be8ed979805078bd650  extensions/portable-verification/schemas/verification-report.schema.json
39139ad3c159d09c756c0f9410cd1ed4804ebaa316ab0378561e53ee854d554f  extensions/signatures/README.md
5fc61584e9296a34fd2047588d733499b231622d02fd34c0ad33a32e5e22c3ad  extensions/signatures/schemas/signatures-attachment.schema.json
c76b4ba43ddc1bd6628db5ea708be147c8a4cd7c6e8d0731a44deacdc44b0088  extensions/signatures/schemas/verification-report.schema.json
3b8aa27b7b7f9e62bb13c47858afa9f1ff01f75f55329eeb79f6287b23e2a388  extensions/signatures/tests/cases.json
7ef6e84d95f4f4d0988de2f834c8a3d7e9c293cea18a70533eab11a27112432b  extensions/signatures/tests/vectors.json
b0b95a5ff4296e732408113c2ebc30d0da7a9926e491cf086dd6fb37e7db0e17  spec/core-00a-title-and-contents.md
6795aeca13d13c2899e89b7988dea48222c5e4cdba9cc87e0fcc0eb27b5e8ef0  spec/core-00b-read-this-first.md
a18b669c3cce88b978a9dd9eaf87289ca11de0c008cb5d6aa8f230eae01b46fb  spec/core-01-preamble-and-scope.md
6c5e28997e1d90415cb876228e827e45049ec2f8a88ac9fb901fcc2ff4ce054a  spec/core-02-definitions.md
cd6bf8ffe5cbe9a4ea57c400e1fb7f7d1ebd318691b97e832a5539e7c07a9f5e  spec/core-03-charter-mechanism.md
37a885d316f87cb15a2b9c2ec2817e6c29ba738b72612a6887d2a9900c907b99  spec/core-04-authority-and-authorship.md
875a512e016ef2cfe1035b5fc97ad979b140428b7febcb21c733ad79e43de2c6  spec/core-05-record-lifecycle.md
7f9694090a423c2c55929b6e14ff1fe6126574ddb283870ed944b0d13872c549  spec/core-06-part1-artifact-set.md
2a99eb1526221dc7fdb76629d8b0a917534aa532ee7e6958fa9642b12e84fdd8  spec/core-06-part2-6.2.3.1-altitude-access-binding.md
1d832dd5f1495e741167949180ec7e92f199f7734b101bbaec0befade20a2dd3  spec/core-06-part3-artifact-set-continued.md
844427b99b1848273e5dca5a18bb0c4fab79dd0baa9e156d9308e7bf2d1ce02e  spec/core-07-conformance-levels.md
90d8e1af8bd46744440db4d2688d4dd4f041a13ff2370c6551ad9d1cb9aea447  spec/core-08-regulatory-cross-references.md
28a8a7d86af6da77289f15925e057392d762569212bb4546133f90fa5093168f  spec/core-09-worked-examples.md
906094374beb77bcac7c26bde7ce27e80dc2296bdff4f8fb6b7bb15bb6a11fcb  spec/core-10-implementation-guidance.md
1af638b2510e7765f55a024aa816a8a2fcca6a52e985176c467acb6c79085ee2  spec/core-11-trademark-governance-adoption.md
527358c53f361a5a16c3affed98d724da4466b645a94ab487d34d8336d63b0aa  spec/core-12-references.md
91a3019b928d0b26ab0bdca503f570f4b9e8c32df868058740dffee5b41d7e81  standard/v5.0/schemas/article-50-disclosure-metadata.json
d4984b6cad84faec9f6ace1c484517e0a00bc8a57a27b37b121db025bbe07b40  standard/v5.0/schemas/charter.schema.json
ff7a2182f143c8e03c02d991584ac61a663cfea4fe144b6898110f9a0c8e05ee  standard/v5.0/schemas/decision-record.schema.json
SUMS
)"
fetch "$LL" lemonnier "$(cat <<'SUMS'
5086c7674db770c6d01592ba697722a2fb468c16d1d5ab9226a7b5217c4bc1a8  examples/release-decision/action-binding-attachment.json
3287e4a527c9bf1736d75f8d36fe36dd71f6ec2f11622d1e7ffaa32445a759d6  examples/release-decision/decision-record.json
3c6c130ed3d5954124dd0832f638b8d8ec2cf7dc6c76d7c9b7407c7e5d5ff6fe  examples/release-decision/summary.json
ae40fd147808b9f61e02d631de691fac4bbf69c9d197e714b3158614e9fbfada  interop/aqta/approval-record/out/action-binding-attachment.json
437c8209a382ed9d087d558ecf83eaa68497818853b92b972734423ffda3ee8a  interop/aqta/approval-record/out/action-record.json
28396e69a24792beabdb03ff2e2cada6fa568d87d270be4c8b2f92305a1f473f  interop/aqta/approval-record/out/approval.canonical.json
f6ee5baa5ba9e88f95e696e5b0ea27b79845e040b012be8af082eab7000363c3  interop/aqta/approval-record/out/arguments.canonical.json
f3a7f8385ee35ccb2f736e81fa1f9e0ed37effc1a96a353a15f6759768cf04fe  interop/aqta/approval-record/out/composition.json
a086dc781c0657c70965f8972e5b9445f224b52ec757235183a5315e61b48d11  interop/aqta/approval-record/out/decision-record.json
b88a03fa7a5d94001d542c509398f782e3c4b88403cddb112810dbcd64599d96  interop/aqta/approval-record/out/negatives/N1-altered-value.json
f47bcb2756976a79d8081b3b32382d81f691d87fa205bb72d3fda9bf1b9bd148  interop/aqta/approval-record/out/negatives/N2-reused-single-use-approval.json
1ad17cf5fd10b4d12a7e93fa78ad2b4938f6f60a400063769019f3e5a4840f5e  interop/aqta/approval-record/out/negatives/N3-approver-outside-trust-policy.json
7de4aa20def0b29e9a2fbe6d51c069e618bec5d2703552eb94566a11ed2ba446  interop/aqta/approval-record/out/negatives/N3b-approver-key-in-wrong-role.json
7b914449eee9d26954228d7d999231daea65edda4d44fef478fc193bb17f12b3  interop/aqta/approval-record/out/negatives/N4-policy-digest-mismatch.json
5a60eef023a3f6110644f79da510995077d4c93e9339879b07fd2b81965f01ab  interop/aqta/approval-record/out/negatives/N5-policy-not-held.json
356a85f1f525c6d2bf1d51816b80f0e4339bf3d1b8ea8beb1b0e22cf73160d7c  interop/aqta/approval-record/out/negatives/N6-attempt-after-policy-limit.json
481d1ed73390c9c6aabfb72d1f5b0ed8611825ed781340c6a5598eb6467ddc31  interop/aqta/approval-record/out/negatives/N7-policy-relabelled-in-specification.json
ac1593d7f2ffa319c435d3e0367e999105f994bff4faffcffb3493762fb411cf  interop/aqta/approval-record/out/negatives/N7b-authority-ref-relabelled.json
9a834e0ab16193a80246fc43270d3a234f13de7393b1bf1f95150a1affe024af  interop/aqta/approval-record/out/negatives/summary.json
6f89d3c6338be7291113bf0e99c676992c3a2493ce271b12d7d7ec08f756b9e8  interop/aqta/approval-record/out/policy.json
ec6e5677469a7a5818308cc2872222c4bacfba9ba2300ad7a19e702e90c49643  interop/aqta/approval-record/out/review-view.txt
870d35367732727f8a729767ebe68714a65b7efda5879a020f8fc1d275887a8a  interop/aqta/approval-record/out/signatures-attachment.json
972eea738a43b09c28b2a231b5db0614453cca894c8762ee1eab499ccdd52625  interop/aqta/approval-record/out/specification.bytes.json
5ba74d2d886ac801c304e9f44c8eb447f22b5a7d934c408d21254a057802294e  interop/aqta/approval-record/out/summary.json
5efb5378cef567119416f7d8b2287d5fc2945711e48139b574d95a5f9b647312  interop/aqta/approval-record/out/trust-policy.json
SUMS
)"
